---
name: mi-app
description: Arma tu app de entrega: tu clienta entra con el mail de su compra y ve sus productos (y los que no compró, con candado y botón para comprar). Gratis, con Google, paso a paso.
---

# Mi app de entrega

Armás con ella **su app de entrega**: una página con sus colores donde la clienta pone **el mail de su compra** y ve sus productos con un botón «Abrir». Lo que todavía no compró aparece con **candado** y un botón «Quiero». La lista de compradoras vive en **una planilla de Google** que solo ella ve. Todo es **gratis** y funciona con su cuenta de Google.

Se activa con: «armá mi app», «quiero mi app de entrega», «que mis clientas entren con su mail», «cómo entrego mi producto».

## Cómo hablás
Español rioplatense con voseo (o «tú» si ella escribe así), cálido y muy paso a paso. **Un paso por mensaje.** Esperá su «listo» antes de seguir. Decile exactamente dónde hacer clic, con el nombre del botón entre comillas.

## Cómo funciona (contáselo en 3 líneas)
- **La planilla** = la lista de quién compró y de tus productos.
- **La app** = la página que ve tu clienta (la arma Claude).
- **Google** la publica gratis y te da un enlace para mandar.

## Paso 1 · Datos y vista previa
1. Leé el proyecto («Mi producto · ficha», estilo de **mis-portadas**). Preguntá solo lo que falte: nombre de la app, cómo firma, mail de contacto, colores y letras, y 3 a 7 frases cortas con su voz para la «frase del día» (opcional).
2. Tomá `vista-previa.html`, cambiá el bloque `CONFIG` y los productos de `DEMO` con los de ella y mostralo como **artefacto**. Decile que pruebe con `prueba@mail.com` (entra) y con otro mail (no entra).
3. Ajustá colores o textos hasta que le guste.

## Paso 2 · Su producto en Google Drive
1. Que suba el PDF a **drive.google.com** → «Nuevo» → «Subir archivo».
2. Clic derecho en el archivo → «Compartir» → en «Acceso general» elegir **«Cualquier persona con el enlace»** (Lector) → «Copiar enlace» → «Listo».
3. Que te pegue el enlace. Repetí con cada producto o regalo.

## Paso 3 · La planilla y el código
Seguí `instalar.md` **paso por paso, de a uno**. Antes de pasarle el código:
- En `Code.gs` cambiá solo el bloque `CONFIG` con los datos del paso 1.
- `Index.html` va **tal cual**, sin cambios.
Dale cada archivo en un bloque de código para copiar entero.

## Paso 4 · Cargar productos y compradoras
En la planilla, hoja **Productos** (una fila por producto):

| id | nombre | descripcion | emoji | link | link_de_compra | precio | visible |
|---|---|---|---|---|---|---|---|
| journal | Volver a mí | Tu journal de 21 días | 📘 | enlace de Drive | (vacío) | (vacío) | si |
| regalo | Meditación | Audio de bienvenida | 🎧 | enlace de Drive | | | si |
| journal2 | Segundo journal | Para seguir | 🌸 | enlace de Drive | link de pago | US$ 9 | si |

Hoja **Compradoras** (una fila por compra):

| mail | nombre | productos | fecha |
|---|---|---|---|
| clienta@mail.com | Ana | journal, regalo | 26/11 |

- En `productos` van los **id** separados por coma, o `todos`.
- El enlace de Drive de un producto **solo le llega a quien lo compró**: a las demás les aparece con candado.

## Paso 5 · Probar y compartir
1. Abrí el enlace de la app en el celular y entrá con un mail cargado.
2. Probá con un mail que no esté: tiene que decir que no lo encuentra.
3. «📲 Poner en mi pantalla de inicio» y seguí los pasos.
4. Escribí con ella el **mail de entrega**: gracias + enlace de la app + «entrá con el mismo mail de tu compra» + a quién escribir. Corto y con su voz, firmado por ella.

## Cada vez que alguien compra
Sumar una fila en **Compradoras** con su mail y el id del producto. Listo: ya entra.
Si quiere que se cargue solo, ayudala a conectarlo con su plataforma de pago (muchas mandan un aviso por mail o por «webhook» a cada venta). Hacelo solo si ella lo pide, y explicándole cada paso.

## Si algo falla
| Pasa esto | Qué hacer |
|---|---|
| «No encuentro ese mail» con una compradora real | Revisar espacios o mayúsculas en la planilla y que esté en la hoja **Compradoras** |
| Google muestra «Esta app no está verificada» | Es normal la primera vez: «Configuración avanzada» → «Ir a … (no seguro)» → «Permitir». Es su propia app |
| Cambié el código y no se ve | «Implementar» → «Gestionar implementaciones» → lápiz → Versión «Nueva versión» → «Implementar» |
| El botón «Abrir» no abre | El archivo de Drive no está compartido «con cualquier persona con el enlace» |

## Reglas
- Nunca pedirle contraseñas, claves ni datos de tarjeta. Ella hace los clics de permisos.
- En la planilla solo mail, nombre, productos y fecha.
- Los textos de la app, con su voz. Nada inventado.
- Cerrá con: «Tu negocio ya tiene producto, portada, página y app 🎉».
