# Instalar la app (de a un paso, esperando «listo»)

1. **Planilla nueva:** entrá a **sheets.new** (abre una planilla en blanco). Arriba a la izquierda, cambiale el nombre por «Mi app · compradoras».
2. **Abrir el editor:** menú **«Extensiones»** → **«Apps Script»**. Se abre una pestaña nueva con un archivo `Código.gs`.
3. **Pegar el código:** borrá todo lo que hay en `Código.gs` y pegá el `Code.gs` que te paso. Tocá el disquete **«Guardar»**.
4. **Crear la página:** a la izquierda, al lado de «Archivos», tocá **«+»** → **«HTML»** → escribí **Index** (con I mayúscula, sin «.html») → Enter. Borrá lo que trae y pegá el `Index.html` que te paso. «Guardar».
5. **Preparar la planilla:** arriba, en la lista de funciones, elegí **prepararPlanilla** → **«Ejecutar»**.
   - Te pide permisos: «Revisar permisos» → elegí tu cuenta → si dice «Google no verificó esta app»: **«Configuración avanzada»** → **«Ir a … (no seguro)»** → **«Permitir»**. Es tu propia app, es seguro.
   - Volvé a la planilla: ahora tiene las hojas **Compradoras** y **Productos** con un ejemplo.
6. **Publicar:** en Apps Script, arriba a la derecha **«Implementar»** → **«Nueva implementación»** → engranaje → **«Aplicación web»**.
   - Descripción: «Mi app».
   - Ejecutar como: **«Yo»**.
   - Quién tiene acceso: **«Cualquier persona»**.
   - **«Implementar»** → copiá la **URL de la aplicación web**. ¡Ese es el enlace de tu app!
7. **Cargar tus datos:** completá la hoja **Productos** con tus enlaces de Drive y sumá tu mail en **Compradoras** con `todos` para probar.
8. **Probar:** abrí el enlace en el celular y entrá con tu mail.

> Si más adelante cambiás el código: «Implementar» → «Gestionar implementaciones» → lápiz ✏️ → Versión: «Nueva versión» → «Implementar». El enlace sigue siendo el mismo.
> Si solo cambiás la planilla (productos o compradoras), no hace falta hacer nada: se ve al instante.
