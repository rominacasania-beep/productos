/**
 * Mi app de entrega · Google Apps Script
 * La clienta entra con su mail: si está en la hoja «Compradoras», ve lo que compró.
 * Lo que no compró aparece con candado y botón de compra.
 *
 * Claude cambia SOLO el bloque CONFIG. Las compradoras y los productos se cargan en la planilla.
 */

const CONFIG = {
  nombreApp: "Mi app",                 // aparece arriba
  autora: "Tu Nombre",
  bienvenida: "Entrá con el mail de tu compra y encontrá todo lo tuyo.",
  colores: { fondo: "#fbf4f2", tinta: "#4a2d35", acento: "#c98b98", claro: "#f1dcdf", sobreAcento: "#ffffff" },
  letraTitulos: "Playfair Display",
  letraCuerpo: "Poppins",
  contacto: "tu@mail.com",             // a quién escribir si no puede entrar
  fraseDelDia: [                       // opcional: una frase distinta cada día (con su voz)
    "Hoy alcanza con dar un paso chiquito.",
    "Lo que escribís, deja de dar vueltas en tu cabeza.",
    "Volver a vos también es avanzar."
  ]
};

/* ====== No hace falta tocar nada de acá para abajo ====== */

function doGet() {
  const t = HtmlService.createTemplateFromFile("Index");
  t.config = JSON.stringify(CONFIG);
  return t.evaluate()
    .setTitle(CONFIG.nombreApp)
    .addMetaTag("viewport", "width=device-width, initial-scale=1, viewport-fit=cover")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** Lo llama la app con el mail que escribió la clienta. */
function entrar(mail) {
  mail = String(mail || "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail)) return { ok: false, motivo: "mail" };

  const libro = SpreadsheetApp.getActiveSpreadsheet();
  const compradoras = filas(libro.getSheetByName("Compradoras"));
  const productos = filas(libro.getSheetByName("Productos"));

  const suyas = compradoras.filter(f => String(f.mail).trim().toLowerCase() === mail);
  if (!suyas.length) return { ok: false, motivo: "no_esta" };

  const nombre = (suyas.find(f => f.nombre) || {}).nombre || "";
  const compro = new Set();
  let todos = false;
  suyas.forEach(f => String(f.productos || "").split(",").forEach(p => {
    p = p.trim().toLowerCase();
    if (p === "todos") todos = true; else if (p) compro.add(p);
  }));

  const lista = productos
    .filter(p => p.id && String(p.visible).toLowerCase() !== "no")
    .map(p => {
      const tiene = todos || compro.has(String(p.id).trim().toLowerCase());
      return {
        id: p.id, nombre: p.nombre, descripcion: p.descripcion || "", emoji: p.emoji || "📘",
        tiene: tiene,
        link: tiene ? (p.link || "") : "",          // el link del producto solo viaja si lo compró
        comprar: tiene ? "" : (p.link_de_compra || ""),
        precio: tiene ? "" : (p.precio || "")
      };
    })
    .sort((a, b) => (b.tiene === a.tiene ? 0 : b.tiene ? 1 : -1));

  return { ok: true, nombre: nombre, productos: lista };
}

/** Convierte una hoja en una lista de objetos usando la primera fila como títulos. */
function filas(hoja) {
  if (!hoja) return [];
  const v = hoja.getDataRange().getValues();
  if (v.length < 2) return [];
  const cab = v[0].map(c => String(c).trim().toLowerCase().replace(/\s+/g, "_"));
  return v.slice(1).filter(r => r.some(x => x !== "")).map(r => {
    const o = {};
    cab.forEach((c, i) => o[c] = r[i]);
    return o;
  });
}

/** Ejecutar UNA vez desde el editor: crea las hojas con sus columnas y un ejemplo. */
function prepararPlanilla() {
  const libro = SpreadsheetApp.getActiveSpreadsheet();
  let c = libro.getSheetByName("Compradoras") || libro.insertSheet("Compradoras");
  if (c.getLastRow() === 0) {
    c.appendRow(["mail", "nombre", "productos", "fecha"]);
    c.appendRow([Session.getActiveUser().getEmail() || "tu@mail.com", "Prueba", "todos", new Date()]);
    c.setFrozenRows(1);
  }
  let p = libro.getSheetByName("Productos") || libro.insertSheet("Productos");
  if (p.getLastRow() === 0) {
    p.appendRow(["id", "nombre", "descripcion", "emoji", "link", "link_de_compra", "precio", "visible"]);
    p.appendRow(["journal", "Mi producto", "Tu producto principal", "📘", "https://drive.google.com/...", "", "", "si"]);
    p.setFrozenRows(1);
  }
  const sobra = libro.getSheetByName("Hoja 1") || libro.getSheetByName("Sheet1");
  if (sobra && libro.getSheets().length > 2 && sobra.getLastRow() === 0) libro.deleteSheet(sobra);
}
