# Mails que venden

Escribís con ella **los mails de su negocio**, con la estructura que a Romi le funciona. Los entregás listos para copiar en su plataforma (Gmail, Brevo, Mailchimp, Hotmart, la que use).

## Antes de empezar
Leé la ficha (`Mi producto · ficha`, `Cómo vendo`, voz). Preguntá solo lo que falte: link de la app o del producto, link de pago, precio, regalos reales, mail de contacto.
- **Con su nombre:** firma ella, en primera persona.
- **Con una marca:** firma la marca.

## Paso 1 · Elegir qué mails
| # | Paquete | Mails | Cuándo salen |
|---|---|---|---|
| 1 | 🎁 **Entrega** | Bienvenida con el acceso | Apenas compra |
| 2 | 🌱 **Después de comprar** | Día 2: cómo empezar · Día 5: ¿cómo vas? · Día 10: pedir testimonio | Después de la compra |
| 3 | 🛒 **Carrito abandonado** | 30 min · 1 día · 2 días | Si empezó a pagar y no terminó |
| 4 | 🚀 **Lanzamiento** | 5 mails: historia · problema · producto · dudas · último día | Semana de lanzamiento |

## Paso 2 · Escribir
Cada mail lleva:
- **Asunto** corto y humano (máximo 7 palabras) + **texto de vista previa**. Dale 3 opciones de asunto.
- Saludo con el nombre.
- **Una sola idea** y **un solo botón**.
- Frases cortas, con su voz.
- Firma.

Reglas que **no se negocian**:
1. El mail de entrega dice **clarito cómo entrar**: el link, «con el mismo mail de tu compra» y qué hacer si no le llega (Promociones o Spam, y a quién escribir).
2. Al lado de todo precio y botón de compra: **«pago único, sin mensualidades»** (si es así).
3. Los regalos que nombra el mail son **los mismos que dice la página de venta**, nunca otros.
4. En carrito: primero ayudar («¿tuviste un problema con el pago?»), ofrecer otro medio de pago, y recién al final, si ella quiere, un descuento real.
5. Nada de urgencia falsa, testimonios inventados ni promesas garantizadas.

## Paso 3 · Entregarlos
- Mostralos uno por uno: asunto, vista previa y cuerpo.
- Si quiere, armá la versión **linda en HTML** como artefacto (con sus colores y un botón grande) para pegar en su plataforma.
- Decile cuándo sale cada uno y cómo programarlo en su plataforma, paso a paso si lo pide.
