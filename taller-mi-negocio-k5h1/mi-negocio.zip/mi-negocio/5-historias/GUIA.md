# Historias que venden

Armás con ella **series de historias de Instagram** para vender su producto sin anuncios, con las reglas que a Romi le funcionan. Entregás el texto de cada historia, qué va en la imagen y qué sticker poner en Instagram.

## Antes de empezar
Leé la ficha (`Mi producto · ficha` y `Cómo vendo`). Si falta cómo vende (con su nombre o con una marca), preguntalo primero (ver SKILL.md).
- **Con su nombre:** primera historia con **su cara o su mano**, habla ella en primera persona.
- **Con una marca:** primera historia con **manos, objetos o el producto en uso**, nunca una cara inventada. Habla la marca.

## Paso 1 · Elegir la serie
Mostrale este menú y que elija (o recomendá una según lo que necesita hoy):

| # | Serie | Para qué | Cuándo |
|---|---|---|---|
| 1 | 🔑 **Imán de palabra clave** | Juntar interesadas: «comentá PALABRA y te lo mando» | Antes de lanzar |
| 2 | 🌸 **Venta suave** | Vender contando una historia real, sin presionar | Cualquier día |
| 3 | 💬 **Abrir conversación** | Que le escriban por privado (encuesta o caja de preguntas) | Cuando está floja la cuenta |
| 4 | 🎥 **Invitación a un vivo** | Llevar gente a un vivo o clase | 2 días antes |
| 5 | 🛠️ **Detrás de escena** | Mostrar cómo crea el producto, generar confianza | Mientras lo arma |
| 6 | ✨ **Frase del día** | Estar presente con algo lindo y corto | Días sin tiempo |

## Paso 2 · Escribir la serie
Reglas que **no se negocian**:
1. **De 3 a 7 historias.** El pedido (sticker de link, «comentá», «escribime») va **antes de la historia 5**.
2. **Una idea por historia.** Máximo 3 líneas cortas de texto.
3. **Hablarle a una persona** («¿te pasa que…?»), nunca «hola a todas».
4. La primera engancha con algo de la vida real, no con el producto.
5. Nada importante en el **borde de arriba ni en el de abajo** de la pantalla: Instagram lo tapa.
6. Los stickers (encuesta, preguntas, link, cuenta regresiva) **se ponen en Instagram**, no se dibujan.
7. Nada de urgencia falsa ni precios en la primera historia.

Entregá una tabla:

| # | Imagen o video | Texto en pantalla | Sticker (en Instagram) |
|---|---|---|---|

## Paso 3 · Que quede lista
- Ofrecé armar las placas como **artefacto**: una tarjeta 9:16 por historia con su texto y sus colores (los de la ficha), para que haga captura o las copie en Instagram.
- Sumá **3 ideas de foto** que pueda sacar con su celular hoy, en su casa.
- Cerrá con: «¿Armamos la de mañana?». Si la serie fue de palabra clave, ofrecé escribir el **mensaje automático** que le llega a quien comenta (parte 6 · Mensajes).
