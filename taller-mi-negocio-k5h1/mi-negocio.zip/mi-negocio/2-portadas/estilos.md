# Estilos base (ajustalos al tema y a ella)

| Estilo | fondo | tinta | acento | claro | Letra de títulos | Sensación |
|---|---|---|---|---|---|---|
| Calma natural | #f4efe6 | #3d3a2f | #8a9a6b | #dfe5cf | Cormorant Garamond | serena, orgánica, cálida |
| Rosa empolvado | #fbf4f2 | #4a2d35 | #c98b98 | #f1dcdf | Playfair Display | femenina, tierna, elegante |
| Noche lila | #1f1630 | #f7f2ff | #b49be8 | #3a2b55 | Cormorant Garamond | mágica, íntima, espiritual |
| Terracota | #f7ede4 | #4b2a1e | #c4683f | #ecd2c2 | DM Serif Display | fuerte, cálida, real |
| Mar | #eef5f6 | #1f3a44 | #4c8c9c | #d3e6ea | Lora | fresca, clara, confiable |
| Sol | #fff8e8 | #3f3220 | #e0a32e | #f6e3b4 | Fraunces | alegre, enérgica, positiva |
| Minimal | #ffffff | #1d1d1f | #1d1d1f | #ececec | Libre Baskerville | limpia, seria, premium |
| Bordó | #f6efe6 | #3a1720 | #6e1e2e | #ebc9c9 | Playfair Display | profunda, elegante, segura |

Letra de textos: siempre una sans limpia (Poppins, Inter, Nunito o DM Sans).

## Cómo elegir
- Emociones, espiritualidad, maternidad → Calma natural, Rosa empolvado, Noche lila.
- Organización, finanzas, estudio → Mar, Minimal.
- Cocina, manualidades, energía → Terracota, Sol.
- Si ella ya tiene colores de marca, usalos siempre por encima de esta tabla.
