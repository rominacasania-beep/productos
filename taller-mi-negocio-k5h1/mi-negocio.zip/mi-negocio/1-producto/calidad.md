# Control de calidad (antes de diseñar)

Revisá todo el contenido y arreglá lo que falle. Mostrale a ella un resumen: ✅ lo que pasa, 🔧 lo que arreglaste.

| # | Control | Pasa si… |
|---|---|---|
| 1 | Promesa | Cada parte acerca a la clienta al resultado prometido |
| 2 | Voz | Suena a ella: sus palabras, su forma de hablar, nada de «robot» |
| 3 | Claridad | Frases cortas, sin palabras técnicas sin explicar |
| 4 | Una persona | Le habla a una sola persona («vos» o «tú», según ella) |
| 5 | Práctica | Cada parte tiene algo para hacer, no solo para leer |
| 6 | Sin repetir | Ninguna idea se repite entre partes |
| 7 | Sin inventos | No hay testimonios, cifras, estudios ni títulos inventados |
| 8 | Cuidado | Sin promesas médicas ni de resultados garantizados |
| 9 | Original | Nada copiado de libros, cursos o plantillas ajenas |
| 10 | Ortografía | Tildes, signos de apertura (¿ ¡) y nombres propios bien escritos |
