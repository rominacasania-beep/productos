# Formatos (etapa 3 y 4)

Elegí el formato por **el resultado que busca la clienta**, no por gusto.

| Formato | Cuándo conviene | Resultado para la clienta |
|---|---|---|
| **Journal** | Emociones, autoestima, duelo, gratitud, maternidad, espiritualidad | Se conoce, ordena lo que siente, se acompaña |
| **Guía** | Algo que se aprende con pasos (cocina, organización, un oficio, un trámite) | Sabe cómo hacerlo |
| **Workbook** | Un cambio que necesita práctica (hábitos, finanzas, emprender) | Lo hace, con ejercicios |
| **Planner** | Rutinas, metas, menús, estudio, presupuesto | Lo organiza y lo sostiene |

## Estructura de cada parte

**Journal**
1. Título de la parte + una frase de apertura de ella.
2. Explicación corta (6 a 10 líneas) con un ejemplo cotidiano.
3. 5 a 8 preguntas para escribir, de las fáciles a las profundas, con renglones.
4. Un ejercicio práctico de 5 minutos.
5. Una frase para cerrar.

**Guía**
1. Título + qué va a lograr en esta parte.
2. Explicación simple con un ejemplo.
3. Pasos numerados (5 a 9), cada uno con «cómo saber que lo hiciste bien».
4. Errores comunes y cómo evitarlos.
5. Una lista para tildar.

**Workbook**
1. Título + por qué importa.
2. Explicación corta.
3. 2 o 3 ejercicios con espacio para completar.
4. Un desafío de 7 días con casillas.
5. Reflexión final (3 preguntas).

**Planner**
1. Portada de la sección + cómo usarla.
2. Plantilla semanal o mensual (tabla).
3. Seguimiento (casillas o gráfico simple para pintar).
4. Página de revisión: qué salió bien, qué cambio.

## Páginas que van siempre
- **Tapa:** nombre, subtítulo y el nombre de ella.
- **Bienvenida:** carta corta de ella + cómo usar el producto (3 a 5 pasos).
- **Índice.**
- **Cierre:** felicitación, qué sigue y cómo encontrarla (Instagram, mail).
- Pie de página discreto con su nombre o su marca.
