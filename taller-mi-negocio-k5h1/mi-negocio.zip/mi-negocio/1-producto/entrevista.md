# Entrevista (etapa 1)

Una pregunta por vez. Si responde corto o general, repreguntá pidiendo **un ejemplo concreto de su vida**. Saltá las que ya estén respondidas en los archivos del proyecto.

1. ¿A qué te dedicás hoy y qué hiciste antes? (trabajos, estudios, cosas que aprendiste sola)
2. ¿Qué te preguntan o te piden seguido tus amigas, tu familia o tus seguidoras?
3. ¿Qué situación difícil superaste que te gustaría que otras sepan cómo atravesar?
4. ¿Qué hacés sin esfuerzo que a otras les cuesta mucho?
5. ¿De qué tema podrías hablar una hora sin preparar nada?
6. ¿A quién te gustaría ayudar? Describila: edad aproximada, qué vive, qué le preocupa a la noche.
7. ¿Cuánto tiempo real tenés por semana para tu negocio?
8. ¿Qué te da miedo o vergüenza de vender por internet?

## Cierre de la etapa
Escribí «Lo que entendí de vos» en 6 líneas, con **sus palabras**:
- Quién es (1 línea)
- Sus 3 saberes más fuertes
- A quién quiere ayudar
- Su tiempo disponible
- Su miedo principal y una frase para tranquilizarla

Preguntá: «¿Corrijo algo?». Con su OK, pasá a la etapa 2.
