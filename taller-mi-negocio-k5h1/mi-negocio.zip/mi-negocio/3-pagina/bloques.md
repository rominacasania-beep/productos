# Los 10 bloques (en este orden)

Cada bloque responde una pregunta que la clienta se hace antes de comprar.

| # | Bloque | La pregunta que responde | Cómo se escribe |
|---|---|---|---|
| 1 | **Arriba** | ¿Esto es para mí? | Título con el **resultado** (máx. 10 palabras) + subtítulo con para quién y en cuánto tiempo + botón «Quiero mi [producto]» (sin precio) |
| 2 | **¿Te pasa esto?** | ¿Me entiende? | 4 frases cortas del dolor, como las diría la clienta. Empiezan con «Sentís que…», «Te pasa que…» |
| 3 | **Qué es** | ¿Qué es exactamente? | El producto en 2 líneas: formato + para quién + resultado |
| 4 | **Qué tiene adentro** | ¿Qué me llevo? | 4 a 6 partes del índice, cada una contada como beneficio («Vas a…») |
| 5 | **Cómo funciona** | ¿Es complicado? | 3 pasos: 1 comprás, 2 te llega al mail o entrás a la app, 3 empezás hoy |
| 6 | **Quién soy** | ¿Por qué ella? | 3 a 5 líneas con su historia real y por qué lo creó |
| 7 | **Regalos** | ¿Hay algo más? | Solo si son reales. Nombre + una línea de cada uno |
| 8 | **Precio** | ¿Cuánto sale? | Precio claro (anterior tachado si hay lanzamiento) + «pago único, sin mensualidades» + botón |
| 9 | **Preguntas frecuentes** | ¿Y si…? | 5 dudas reales: cómo lo recibo, en qué dispositivo, cuánto tiempo lleva, si sirve si empiezo de cero, a quién escribo |
| 10 | **Cierre** | ¿Me animo? | Una frase cálida de ella + botón final |

## Voz
- Hablarle a **una** persona.
- Frases cortas. Una idea por frase.
- Palabras de la clienta, no de marketing («me siento sola», no «gestión emocional»).
- Nada de signos de exclamación seguidos ni MAYÚSCULAS para gritar.
