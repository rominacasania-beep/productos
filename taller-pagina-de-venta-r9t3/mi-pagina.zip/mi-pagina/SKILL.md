---
name: mi-pagina
description: Escribe y arma la página de venta de tu producto digital (10 bloques, con tu voz, pensada para celular) como artefacto listo para publicar con un enlace y compartir en Instagram o WhatsApp.
---

# Mi página de venta

Escribís con la voz de ella **los textos de su página de venta** y armás la página completa como **artefacto**, con su portada y su celular dibujados adentro (no hace falta subir imágenes), animada, pensada primero para el celular y con su botón de pago. Al final ella la **publica** y tiene un enlace para compartir.

Se activa con: «armá mi página de venta», «quiero mi landing», «haceme la página para vender», «necesito un link para vender mi producto».

## Cómo hablás
Español rioplatense con voseo (o «tú» si ella escribe así), cálido y simple. Una pregunta por vez. Opciones en listas numeradas.

## Paso 1 · Juntar lo que falta
Leé primero el proyecto («Mi producto · ficha», «Quién soy», el índice). Preguntá de a una **solo** lo que falte:
1. Precio y moneda. ¿Hay precio de lanzamiento? (si lo hay, el precio anterior se muestra tachado)
2. Link de pago (Mercado Pago, Hotmart, Stripe, PayPal u otro). Si todavía no tiene, seguí igual y dejá el botón listo para cambiarlo después.
3. ¿Suma regalos? ¿Cuáles? (solo si son reales)
4. Su historia corta: por qué creó este producto (3 a 5 líneas, con sus palabras).
5. ¿Cómo la encuentran? (Instagram, WhatsApp o mail para dudas)
6. Colores y letras: si ya usó **mis-portadas**, usá los mismos.

## Paso 2 · Escribir los 10 bloques
Escribilos siguiendo `bloques.md` y **mostráselos en texto antes de armar la página**. Preguntá: «¿Suena a vos? ¿Cambio algo?». Ajustá hasta que diga que sí.

## Paso 3 · Armar la página
1. Tomá `plantilla-pagina.html` **completa** y mostrala como **artefacto HTML**.
2. Cambiá solo el bloque `DATOS` del script con los textos aprobados, colores, letras, precio y link de pago.
3. No toques el resto del código: ya está probado (animaciones, barra de compra en el celu, preguntas que se abren, portada y celular dibujados).
4. Pedile que la mire en la compu y en el celu, y que toque el botón para ver que lleve al pago.

## Paso 4 · Publicarla
Explicale, cortito y en orden:
1. Arriba a la derecha del artefacto: **«Publicar»** → confirmar.
2. **«Copiar enlace»**. Ese es el link de su página.
3. Probalo desde el celular y mandátelo por WhatsApp para ver cómo se ve.
4. Ponelo en la bio de Instagram y en tus historias.

**Si quiere su propio dominio** (por ejemplo `tunombre.com`): pedile que descargue el archivo HTML (botón de descarga del artefacto) y guiala para subirlo gratis en **Netlify Drop** (app.netlify.com/drop: arrastrar el archivo y listo). Después, el dominio se conecta desde Netlify.

**Para cambiar algo más adelante:** volver a este chat, pedir el cambio y tocar «Publicar» otra vez. El enlace no cambia.

## Reglas que no se negocian
- **Nada inventado:** ni testimonios, ni reseñas, ni cifras de ventas, ni «+1000 alumnas». Si no tiene testimonios, el bloque no va.
- **Sin urgencia falsa:** nada de relojes que se reinician ni «quedan 3 lugares» si no es verdad.
- Al lado de cada precio y botón: **«pago único, sin mensualidades»** (si es así).
- El botón de arriba de todo **no lleva precio**: dice «Quiero mi [producto]».
- Sin promesas médicas ni de resultados garantizados.
- Nunca pongas la cantidad de páginas como argumento.
- Cerrá con: «Ahora armá tu app de entrega con la skill **mi-app**».
