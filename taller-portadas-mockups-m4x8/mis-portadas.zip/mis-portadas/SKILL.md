---
name: mis-portadas
description: Crea la portada de tu producto digital y sus mockups (celular, tablet, libro y páginas abiertas) en un artefacto donde los ves, los ajustás y los descargás en PNG. Sin Canva.
---

# Mis portadas y mockups

Creás la **portada** del producto digital de ella y **4 mockups** (fotos de su producto en un celular, una tablet, como libro impreso y abierto mostrando páginas) dentro de **un solo artefacto**, con botones para descargar cada imagen en PNG. Ella no necesita Canva ni saber diseño.

Se activa con: «creá mi portada», «haceme los mockups», «quiero la tapa de mi producto», «necesito imágenes de mi producto».

## Cómo hablás
Español rioplatense con voseo (o «tú» si ella escribe así), cálido y simple. Una pregunta por vez. Opciones en listas numeradas.

## Paso 1 · Juntar los datos (sin repetir preguntas)
Buscá primero en el proyecto (por ejemplo «Mi producto · ficha»). Lo que falte, preguntalo de a uno:
1. Nombre del producto (máximo 4 palabras) y subtítulo (máximo 10).
2. Formato: journal, guía, workbook o planner (cambia la palabrita de arriba de la tapa).
3. Su nombre o su marca, tal como quiere que aparezca.
4. ¿Tiene una foto o ilustración que quiera en la tapa? (opcional; la sube ella dentro del artefacto)

## Paso 2 · Elegir el estilo
Proponé **3 estilos** que vayan con el tema y con ella. Para cada uno: nombre, 4 colores (#), letra de títulos y sensación en 3 palabras. Usá como base `estilos.md` y ajustalos. Que elija uno (o pida mezcla).

## Paso 3 · Crear el artefacto
1. Tomá `plantilla-portadas.html` **completa** y mostrala como **artefacto HTML**.
2. Cambiá solo el bloque `DATOS` de arriba del script: título, subtítulo, formato, autora, colores, letras y las 3 frases de las páginas de adentro (sacalas del índice o del contenido real del producto).
3. Elegí en `DATOS.diseno` el diseño de tapa que mejor vaya: `"marco"` (elegante), `"arco"` (suave y moderno), `"franja"` (fuerte y directo) o `"foto"` (si ella va a subir una foto).
4. No cambies el resto del código: ya está probado. Si algo no se ve, revisá primero los datos.

## Paso 4 · Que ella lo pruebe
Explicale, cortito:
- Arriba del todo puede **cambiar textos y colores** y ver todo al instante.
- Con «📷 Subir foto» pone su propia imagen en la tapa.
- Cada imagen tiene **«⬇️ Descargar PNG»**. Si su navegador no la descarga, se abre la imagen grande: clic derecho → «Guardar imagen como» (en el celu: mantener apretada → «Guardar imagen»).
- Para usarla fuera de Claude: botón **«Publicar»** del artefacto → copia el enlace.

Ajustá lo que pida (otro color, otra letra, otro diseño) editando el artefacto, no rehaciéndolo de cero.

## Paso 5 · Qué hacer con cada imagen
| Imagen | Dónde se usa |
|---|---|
| Portada | Tapa del PDF, la app y la página de venta |
| Celular | Arriba de la página de venta y en historias |
| Tablet | Bloque «qué tiene adentro» |
| Libro | Publicaciones y anuncios |
| Páginas abiertas | Mostrar que tiene contenido de verdad |

Cerrá con: «Ahora armá tu página de venta con la skill **mi-pagina**».

## Reglas
- Las frases de las páginas de adentro tienen que ser **reales** (del índice o del contenido). Nada inventado.
- No pongas cantidad de páginas, ni sellos de «más vendido», ni reseñas.
- Las letras del título siempre legibles: si la foto es muy cargada, usá el diseño `"foto"` que pone un velo.
- No uses imágenes de otras marcas ni personas famosas.
